// JavaScript for Stopwatch Functionality
let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let timer;

function startStopwatch() {
  if (!timer) {
    timer = setInterval(run, 10);
  }
}

function run() {
  milliseconds++;
  if (milliseconds === 100) {
    milliseconds = 0;
    seconds++;
  }
  if (seconds === 60) {
    seconds = 0;
    minutes++;
  }

  document.getElementById("minutes").innerText = formatTime(minutes);
  document.getElementById("seconds").innerText = formatTime(seconds);
  document.getElementById("milliseconds").innerText = formatTime(milliseconds);
}

function pauseStopwatch() {
  clearInterval(timer);
  timer = false;
}

function resetStopwatch() {
  clearInterval(timer);
  timer = false;
  minutes = 0;
  seconds = 0;
  milliseconds = 0;
  document.getElementById("minutes").innerText = "00";
  document.getElementById("seconds").innerText = "00";
  document.getElementById("milliseconds").innerText = "00";
}

function formatTime(time) {
  return time < 10 ? `0${time}` : time;
}
