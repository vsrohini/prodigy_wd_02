# stop watch

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rohini-VS-the-vuer/pen/gOVyRxy](https://codepen.io/Rohini-VS-the-vuer/pen/gOVyRxy).

